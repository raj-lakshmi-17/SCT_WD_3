/**
 * main.js — NexaFlow Landing Page
 * Vanilla JavaScript only · Beginner-friendly with inline comments
 * ---------------------------------------------------------------
 * Features:
 *  1. Navbar scroll detection (transparent → frosted glass)
 *  2. Active nav link highlighting based on scroll position
 *  3. Hamburger / mobile menu toggle
 *  4. Smooth-close mobile menu when a link is clicked
 *  5. Scroll-reveal animation (IntersectionObserver)
 *  6. Counter animation for stats numbers
 *  7. Contact form validation + success feedback
 *  8. Keyboard accessibility (trap focus in mobile menu, ESC to close)
 */

/* ============================================================
   0. UTILITY HELPERS
   ============================================================ */

/**
 * Clamp a number between min and max.
 */
function clamp(val, min, max) {
  return Math.min(Math.max(val, min), max);
}

/**
 * Ease-out cubic function for animations.
 */
function easeOutCubic(t) {
  return 1 - Math.pow(1 - t, 3);
}

/* ============================================================
   1. NAVBAR — SCROLL DETECTION
   ============================================================ */

(function initNavbar() {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;

  let lastScrollY = window.scrollY;
  let ticking = false; // prevent firing too many times per frame

  /**
   * Update navbar classes based on scroll position.
   * - "at-top"  → transparent background (page not scrolled)
   * - "scrolled" → frosted-glass background (page scrolled)
   */
  function updateNavbar() {
    const scrollY = window.scrollY;

    if (scrollY <= 10) {
      // At the very top — make navbar transparent
      navbar.classList.add('at-top');
      navbar.classList.remove('scrolled');
    } else {
      // Scrolled down — apply frosted glass style
      navbar.classList.remove('at-top');
      navbar.classList.add('scrolled');
    }

    lastScrollY = scrollY;
    ticking = false;
  }

  // Initialise correct state on page load
  updateNavbar();

  // Listen to scroll events; use requestAnimationFrame for performance
  window.addEventListener('scroll', function () {
    if (!ticking) {
      window.requestAnimationFrame(updateNavbar);
      ticking = true;
    }
  }, { passive: true });
})();


/* ============================================================
   2. ACTIVE NAV LINK — SECTION TRACKING
   ============================================================ */

(function initActiveLinks() {
  // All the sections we want to track
  const sectionIds = ['home', 'features', 'about', 'contact'];

  // Map section id → desktop nav link element
  const linkMap = {
    home:     document.getElementById('navl-home'),
    features: document.getElementById('navl-features'),
    about:    document.getElementById('navl-about'),
    contact:  document.getElementById('navl-contact'),
  };

  /**
   * Find which section is currently in view and mark
   * its corresponding nav link as "active".
   */
  function updateActiveLink() {
    const scrollY = window.scrollY;
    const navHeight = parseInt(
      getComputedStyle(document.documentElement).getPropertyValue('--nav-height'),
      10
    ) || 72;

    let currentSection = 'home'; // default fallback

    sectionIds.forEach(function (id) {
      const el = document.getElementById(id);
      if (!el) return;

      // A section is "active" when its top edge is within the viewport
      // accounting for the fixed navbar height plus a small buffer
      if (el.getBoundingClientRect().top <= navHeight + 60) {
        currentSection = id;
      }
    });

    // Remove active class from all links, then add to current
    Object.values(linkMap).forEach(function (link) {
      if (link) link.classList.remove('active');
    });

    if (linkMap[currentSection]) {
      linkMap[currentSection].classList.add('active');
    }
  }

  window.addEventListener('scroll', updateActiveLink, { passive: true });
  updateActiveLink(); // run once on load
})();


/* ============================================================
   3. HAMBURGER / MOBILE MENU TOGGLE
   ============================================================ */

(function initMobileMenu() {
  const hamburger = document.getElementById('hamburger-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  const mobileLinks = mobileMenu ? mobileMenu.querySelectorAll('.mob-link, .mob-cta') : [];

  if (!hamburger || !mobileMenu) return;

  let isOpen = false;

  /**
   * Open or close the mobile menu.
   */
  function toggleMenu(forceClose) {
    isOpen = forceClose === true ? false : !isOpen;

    // Toggle CSS classes
    hamburger.classList.toggle('open', isOpen);
    mobileMenu.classList.toggle('open', isOpen);

    // Update ARIA attributes for accessibility
    hamburger.setAttribute('aria-expanded', String(isOpen));
    mobileMenu.setAttribute('aria-hidden', String(!isOpen));
  }

  // Click hamburger
  hamburger.addEventListener('click', function () {
    toggleMenu();
  });

  // Click any mobile menu link → close menu
  mobileLinks.forEach(function (link) {
    link.addEventListener('click', function () {
      toggleMenu(true);
    });
  });

  // Press ESC to close menu
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && isOpen) {
      toggleMenu(true);
      hamburger.focus(); // return focus to hamburger for accessibility
    }
  });

  // Click outside the menu (but not on hamburger) to close it
  document.addEventListener('click', function (e) {
    if (isOpen && !mobileMenu.contains(e.target) && !hamburger.contains(e.target)) {
      toggleMenu(true);
    }
  });
})();


/* ============================================================
   4. SMOOTH SCROLL — support for browsers without native support
   ============================================================ */

(function initSmoothScroll() {
  // Grab all anchor links that point to an on-page id (e.g. href="#features")
  const allAnchorLinks = document.querySelectorAll('a[href^="#"]');
  const navHeight = parseInt(
    getComputedStyle(document.documentElement).getPropertyValue('--nav-height'),
    10
  ) || 72;

  allAnchorLinks.forEach(function (link) {
    link.addEventListener('click', function (e) {
      const targetId = link.getAttribute('href').slice(1); // strip the "#"
      const targetEl = document.getElementById(targetId);

      if (!targetEl) return;

      e.preventDefault();

      // Calculate scroll position, accounting for fixed navbar
      const targetTop =
        targetEl.getBoundingClientRect().top +
        window.scrollY -
        navHeight;

      window.scrollTo({ top: targetTop, behavior: 'smooth' });
    });
  });
})();


/* ============================================================
   5. SCROLL-REVEAL ANIMATIONS (IntersectionObserver)
   ============================================================ */

(function initScrollReveal() {
  // Select every element with class "reveal"
  const revealEls = document.querySelectorAll('.reveal');

  if (!revealEls.length) return;

  // IntersectionObserver fires the callback whenever an element
  // enters or leaves the viewport
  const observer = new IntersectionObserver(
    function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          // Element is visible — add "visible" class to trigger CSS transition
          entry.target.classList.add('visible');
          // Unobserve so the animation doesn't re-trigger on scroll back up
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.12,   // trigger when 12% of the element is visible
      rootMargin: '0px 0px -40px 0px', // offset so it triggers slightly before visible
    }
  );

  revealEls.forEach(function (el) {
    observer.observe(el);
  });
})();


/* ============================================================
   6. ANIMATED COUNTER — Stats section
   ============================================================ */

(function initCounters() {
  // Find all stat number elements with a "data-target" attribute
  const counterEls = document.querySelectorAll('.stat-num[data-target]');

  if (!counterEls.length) return;

  /**
   * Animate a number from 0 to its target value over a given duration.
   */
  function animateCounter(el) {
    const target  = parseInt(el.getAttribute('data-target'), 10);
    const duration = 1800; // animation duration in ms
    const startTime = performance.now();

    function step(currentTime) {
      const elapsed  = currentTime - startTime;
      const progress = clamp(elapsed / duration, 0, 1);
      const value    = Math.round(easeOutCubic(progress) * target);

      // Format large numbers with commas (e.g. 10,000)
      el.textContent = value.toLocaleString();

      if (progress < 1) {
        requestAnimationFrame(step);
      }
    }

    requestAnimationFrame(step);
  }

  // Use IntersectionObserver to start animation only when stats are visible
  const observer = new IntersectionObserver(
    function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          counterEls.forEach(animateCounter);
          observer.disconnect(); // only run once
        }
      });
    },
    { threshold: 0.3 }
  );

  // Observe the stats bar wrapper
  const statsBar = document.getElementById('stats-bar');
  if (statsBar) observer.observe(statsBar);
})();


/* ============================================================
   7. CONTACT FORM — VALIDATION + SUBMISSION FEEDBACK
   ============================================================ */

(function initContactForm() {
  const form       = document.getElementById('contact-form');
  if (!form) return;

  const nameInput  = document.getElementById('f-name');
  const emailInput = document.getElementById('f-email');
  const msgInput   = document.getElementById('f-msg');
  const submitBtn  = document.getElementById('form-submit-btn');
  const submitTxt  = document.getElementById('submit-txt');
  const successEl  = document.getElementById('form-success');

  // Error elements
  const errName  = document.getElementById('err-name');
  const errEmail = document.getElementById('err-email');
  const errMsg   = document.getElementById('err-msg');

  /**
   * Show an error message below a field.
   */
  function showError(input, errEl, message) {
    input.classList.add('error');
    errEl.textContent = message;
  }

  /**
   * Clear error state from a field.
   */
  function clearError(input, errEl) {
    input.classList.remove('error');
    errEl.textContent = '';
  }

  /**
   * Validate a single email string.
   * Simple regex — covers the vast majority of real addresses.
   */
  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  }

  /**
   * Validate all form fields.
   * Returns true if all fields pass, false if any fail.
   */
  function validateForm() {
    let valid = true;

    // Name: required, minimum 2 characters
    if (nameInput.value.trim().length < 2) {
      showError(nameInput, errName, 'Please enter your full name (at least 2 characters).');
      valid = false;
    } else {
      clearError(nameInput, errName);
    }

    // Email: required, valid format
    if (!nameInput.value.trim()) {
      // already caught above
    }
    if (!isValidEmail(emailInput.value)) {
      showError(emailInput, errEmail, 'Please enter a valid email address.');
      valid = false;
    } else {
      clearError(emailInput, errEmail);
    }

    // Message: required, minimum 10 characters
    if (msgInput.value.trim().length < 10) {
      showError(msgInput, errMsg, 'Your message must be at least 10 characters long.');
      valid = false;
    } else {
      clearError(msgInput, errMsg);
    }

    return valid;
  }

  // Clear error on input (instant feedback as user types)
  nameInput.addEventListener('input',  function () { clearError(nameInput,  errName);  });
  emailInput.addEventListener('input', function () { clearError(emailInput, errEmail); });
  msgInput.addEventListener('input',   function () { clearError(msgInput,   errMsg);   });

  /**
   * Handle form submission.
   */
  form.addEventListener('submit', function (e) {
    e.preventDefault(); // prevent real HTTP submission

    // Validate first
    if (!validateForm()) return;

    // Show loading state on the button
    submitBtn.disabled = true;
    submitTxt.textContent = 'Sending…';

    // Simulate an async network request (replace with real fetch() call)
    setTimeout(function () {
      // Reset button
      submitBtn.disabled = false;
      submitTxt.textContent = 'Send Message';

      // Show success message
      successEl.textContent = '🎉 Message sent! We\'ll get back to you within 24 hours.';

      // Reset the form fields
      form.reset();

      // Hide success message after 6 seconds
      setTimeout(function () {
        successEl.textContent = '';
      }, 6000);
    }, 1400); // simulated 1.4s network delay
  });
})();


/* ============================================================
   8. HERO VISUAL — SUBTLE PARALLAX ON MOUSE MOVE (desktop)
   ============================================================ */

(function initHeroParallax() {
  const heroVisual = document.getElementById('hero-visual');
  if (!heroVisual) return;

  // Only apply on devices that support hover (non-touch)
  const mq = window.matchMedia('(hover: hover) and (min-width: 1024px)');
  if (!mq.matches) return;

  let raf;
  let targetX = 0, targetY = 0;
  let currentX = 0, currentY = 0;

  document.addEventListener('mousemove', function (e) {
    // Normalise mouse position to -1 … +1 range
    const nx = (e.clientX / window.innerWidth  - 0.5) * 2;
    const ny = (e.clientY / window.innerHeight - 0.5) * 2;

    // Scale movement amount (px)
    targetX = nx * 14;
    targetY = ny * 10;
  });

  function loop() {
    // Lerp (linear interpolation) for smooth movement
    currentX += (targetX - currentX) * 0.07;
    currentY += (targetY - currentY) * 0.07;

    heroVisual.style.transform =
      `translate(${currentX.toFixed(2)}px, ${currentY.toFixed(2)}px)`;

    raf = requestAnimationFrame(loop);
  }

  loop();
})();


/* ============================================================
   9. FEATURE CARDS — TILT ON HOVER (desktop)
   ============================================================ */

(function initCardTilt() {
  const cards = document.querySelectorAll('.feat-card');

  // Only apply on pointer devices
  if (!window.matchMedia('(hover: hover)').matches) return;

  const TILT_AMOUNT = 8; // max degrees of tilt

  cards.forEach(function (card) {
    card.addEventListener('mousemove', function (e) {
      const rect   = card.getBoundingClientRect();
      // Position of cursor relative to card centre, normalised -1…+1
      const cx     = (e.clientX - rect.left - rect.width  / 2) / (rect.width  / 2);
      const cy     = (e.clientY - rect.top  - rect.height / 2) / (rect.height / 2);

      const rotateY =  cx * TILT_AMOUNT;
      const rotateX = -cy * TILT_AMOUNT;

      card.style.transform =
        `translateY(-10px) scale(1.01) perspective(600px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
    });

    card.addEventListener('mouseleave', function () {
      // Reset to the CSS default on leave
      card.style.transform = '';
    });
  });
})();


/* ============================================================
   10. PAGE LOAD — REMOVE NO-JS FALLBACK
   ============================================================ */

// Mark body as JS-enabled (can use for CSS overrides if needed)
document.documentElement.classList.add('js-ready');

// Log confirmation to console (helpful for debugging)
console.log('%cNexaFlow JS initialised ✓', 'color:#6C63FF;font-weight:700;font-size:14px');
